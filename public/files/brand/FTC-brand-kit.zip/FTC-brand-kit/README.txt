FINANCIAL TRANSPARENCY COALITION - BRAND KIT
Version 1.0 - November 2026

Read the Brand Guidelines (FTC-Brand-Guidelines.pdf) first, then use these files. They tell you which logo to use where.

01-logo/
  horizontal/   The main logo: symbol + wordmark side by side. Use it by default.
  stacked/      Symbol above the wordmark, for narrow or tall spaces.
  symbol/       The symbol alone, only where the FTC name already appears nearby
                or for very small sizes (avatars, favicons, page footers).
  Each folder has:
    svg/  Vector files. Use them for print, the web and for resizing to any size.
    png/  Transparent images in three sizes, for Word, PowerPoint and email.
  Colour versions:
    colour    navy and blue, on white or light backgrounds (the default)
    negative  white and sky blue, on navy or dark photos
    navy      single colour, for one-colour printing
    black     single colour, for black-and-white printing and faxes
    white     single colour, on coloured or busy backgrounds

02-colours-and-type/
  The palette and typefaces are in the Brand Guidelines.
  Fonts: Archivo (headings and the web) and Inter (body text in documents).
  Both are free from Google Fonts: fonts.google.com/specimen/Archivo and
  fonts.google.com/specimen/Inter. Where they are not installed, use Arial.

03-social/
  avatar-navy-1080.png      Profile picture (default). Works in square and round crops.
  avatar-white-1080.png     Profile picture for platforms with dark interfaces.
  linkedin-cover-1584x396   LinkedIn page cover.
  x-header-1500x500         X (Twitter) header.
  facebook-cover-1640x624   Facebook page cover.
  youtube-banner-2560x1440  YouTube channel banner (logo inside the safe area
                            for TV, desktop and mobile).

04-email-signature/
  signature.html            Open in a browser, replace the [bracketed] text,
                            select all, copy and paste into your email signature.
  ftc-email-logo.png        The logo the signature loads from the website.

05-favicon/
  Website icons (already installed on financialtransparency.org).

Contact: info@financialtransparency.org
